# SQL Mapping Reference

The schema is created by Flyway (`V1`–`V3`); Hibernate only **validates** it (`ddl-auto=validate`).
Only tables the Java code writes through JPA have entities; the rest are written by stored procedures/triggers and read with `JdbcTemplate`.

| Java | Table | Notes |
|------|-------|-------|
| `User` | `users` | login accounts, BCrypt hash |
| `FoodListing` | `food_listings` | inserted via JPA; `trg_listing_*` fire on insert |
| (read via SQL) | `localities`, `food_types`, `donors`, `ngos`, `ngo_food_types`, `volunteers` | reference data, seeded in V3 |
| (written by `sp_assign_pickup`) | `pickups` | `listing_id` UNIQUE: one pickup per listing |
| (written by triggers) | `pickup_history`, `notifications` | audit trail and NGO alerts |
| (written by `sp_match_candidates`) | `match_log` | audit of every candidate: donor, NGO, scores, criteria |

## Normalization (3NF)
Locality coordinates live once in `localities`; food types once in `food_types`; the NGO↔food-type many-to-many is `ngo_food_types`.
Listings/pickups reference these by FK, so no coordinate or name is repeated.

## Matching rule (`sp_match_candidates`)
Hard filters: NGO accepts the food type · distance ≤ `service_radius_km` · quantity within `[min_batch_kg, max_batch_kg]` ·
`hours_to_expiry × 60 ≥ distance × 2.4 + 30` (≈25 km/h plus 30 min handling).
Score: `priority = 0.5·proximity + 0.3·quantity + 0.2·urgency`
- proximity = `1 − distance / radius`
- quantity = `min(1, qty / max_batch_kg)`
- urgency = `1 − hours_to_expiry / 24`, clamped to 0..1

Verdict: `MATCH ≥ 0.60`, `REVIEW ≥ 0.35`, else `WEAK`.

## Triggers
| Trigger | Event | Effect |
|---------|-------|--------|
| `trg_listing_before_insert` | BEFORE INSERT `food_listings` | rejects quantity ≤ 0 or past expiry (`SIGNAL 45000` → HTTP 400) |
| `trg_listing_after_insert` | AFTER INSERT `food_listings` | inserts a `notifications` row for each eligible NGO |
| `trg_pickup_after_insert` | AFTER INSERT `pickups` | listing → `MATCHED`, volunteer busy, first `pickup_history` row |
| `trg_pickup_after_update` | AFTER UPDATE `pickups` | logs history, syncs listing status, frees volunteer on `DELIVERED` |

## Request → DB flow
```
POST /api/listings → ListingService.create → FoodListingRepository.save
   → INSERT food_listings → [BEFORE trigger validates] → [AFTER trigger notifies NGOs]
   → CALL sp_match_listing → INSERT match_log → ranked JSON
POST /api/pickups  → CALL sp_assign_pickup → INSERT pickups → [trigger: MATCHED, volunteer busy, history]
PUT  /api/pickups/{id}/status → CALL sp_update_pickup_status → UPDATE pickups → [trigger: history, listing status]
```
