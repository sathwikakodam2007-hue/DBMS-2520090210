# Food Donation & NGO Connect Platform: Full Stack (Java + MySQL)

Spring Boot backend + single-page frontend, served as **one application on one port**.
Built with the same structure as the Entity-Resolution project (Spring Boot 3.3, Spring Security + JWT, JPA, Flyway, MySQL),
but the matching logic lives **inside MySQL** (stored procedures, triggers, a stored function), as described in the project report.

## What's inside
- `pom.xml`: Maven build
- `src/main/resources/db/migration/`
  - `V1__init_schema.sql`: 3NF schema (12 tables, PK/FK constraints, B-tree index on `(status, expiry_time)`)
  - `V2__triggers_procedures.sql`: `fn_distance_km`, `sp_match_candidates`, `sp_match_listing`, `sp_assign_pickup`, `sp_update_pickup_status`, 4 triggers
  - `V3__seed_data.sql`: Hyderabad localities, food types and **fictional** sample donors / NGOs / volunteers
- `src/main/java/com/fooddonation/`: entities, services, controllers, JWT security
- `src/main/resources/static/index.html`: report-style page + live matching demo + donor dashboard
- `SQL_MAPPING.md`: Java ↔ SQL mapping and the matching rules

## 1. Prerequisites
Java 17+, Maven 3.9+, MySQL 8 running locally.

## 2. Configure
Edit `src/main/resources/application.properties` if your MySQL credentials differ:
```properties
spring.datasource.username=root
spring.datasource.password=yourpassword
```
Flyway creates the `fooddonation` database objects automatically (the JDBC URL has `createDatabaseIfNotExist=true`).
The Flyway user needs permission to create triggers/functions (root has it).

## 3. Run
```bash
mvn spring-boot:run
```
Open `http://localhost:8080`.

## 4. Try it
1. **Live demo** (no login): pick a locality, food type, kg and hours to expiry → **Run matching engine**.
   Every candidate is saved in `match_log`.
2. **Register / Log in**, then use the **Dashboard**: *Post donation* (trigger notifies NGOs, ranked matches appear) →
   *Confirm pickup* (nearest free volunteer assigned) → *Mark picked up* → *Mark delivered* → *History*.
3. Verify in MySQL:
```sql
USE fooddonation;
SELECT * FROM food_listings;
SELECT * FROM notifications ORDER BY id DESC;
SELECT * FROM match_log ORDER BY id DESC LIMIT 10;
SELECT * FROM pickup_history;
```

## API endpoints
| Method | Path | Auth | Purpose |
|--------|------|------|---------|
| POST | `/api/auth/register` | No | Create account, returns JWT |
| POST | `/api/auth/login` | No | Login, returns JWT |
| GET | `/api/lookups` | No | Localities, food types, donors, NGOs |
| POST | `/api/match` | No (open demo) | Rank NGOs for an ad-hoc donation, logs to `match_log` |
| GET | `/api/listings` | Yes | Latest 50 listings with pickup/NGO/volunteer |
| POST | `/api/listings` | Yes | Create listing (trigger notifies NGOs) and return ranked matches |
| GET | `/api/listings/{id}/matches` | Yes | Re-run matching for an AVAILABLE listing |
| DELETE | `/api/listings/{id}` | Yes | Remove an AVAILABLE listing |
| POST | `/api/pickups` | Yes | Confirm `{listingId, ngoId}`; assigns nearest free volunteer |
| PUT | `/api/pickups/{id}/status` | Yes | `PICKED_UP` then `DELIVERED` |
| GET | `/api/pickups/{id}/history` | Yes | Audit trail of status changes |

## Notes
- Locations are **locality centroids** (coarse, ~km accuracy). Swap in real geocoding for production.
- All timestamps are stored in UTC (`connectionTimeZone=UTC` in the JDBC URL).
- Any logged-in user can act on any listing: there is no donor/NGO/volunteer role model yet (see Future scope in the report).
- Change `app.jwt.secret` before deploying; tighten CORS in `SecurityConfig` for real origins.
