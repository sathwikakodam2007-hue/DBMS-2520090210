package com.fooddonation.dto;

import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.NotNull;
import java.math.BigDecimal;

/** Ad-hoc donation used by the public matching demo (nothing is stored as a listing). */
public class MatchRequest {
    @NotNull(message = "Pick a pickup locality.")
    private Integer localityId;
    @NotNull(message = "Pick a food type.")
    private Integer foodTypeId;
    @NotNull @DecimalMin(value = "0.1", message = "Quantity must be at least 0.1 kg.")
    private BigDecimal quantityKg;
    @NotNull @DecimalMin(value = "0.5", message = "Hours until expiry must be at least 0.5.")
    private BigDecimal hoursUntilExpiry;

    public Integer getLocalityId() { return localityId; }
    public void setLocalityId(Integer localityId) { this.localityId = localityId; }
    public Integer getFoodTypeId() { return foodTypeId; }
    public void setFoodTypeId(Integer foodTypeId) { this.foodTypeId = foodTypeId; }
    public BigDecimal getQuantityKg() { return quantityKg; }
    public void setQuantityKg(BigDecimal quantityKg) { this.quantityKg = quantityKg; }
    public BigDecimal getHoursUntilExpiry() { return hoursUntilExpiry; }
    public void setHoursUntilExpiry(BigDecimal hoursUntilExpiry) { this.hoursUntilExpiry = hoursUntilExpiry; }
}
