package com.fooddonation.service;

import com.fooddonation.dto.ListingRequest;
import com.fooddonation.entity.FoodListing;
import com.fooddonation.exception.ApiException;
import com.fooddonation.repository.FoodListingRepository;
import org.springframework.http.HttpStatus;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.util.List;
import java.util.Map;

@Service
public class ListingService {

    private final FoodListingRepository repo;
    private final JdbcTemplate jdbc;
    private final MatchingService matching;

    public ListingService(FoodListingRepository repo, JdbcTemplate jdbc, MatchingService matching) {
        this.repo = repo;
        this.jdbc = jdbc;
        this.matching = matching;
    }

    public List<Map<String, Object>> findAll() {
        return jdbc.queryForList(
                "SELECT l.id, d.name AS donor, ft.name AS foodType, l.description, l.quantity_kg AS quantityKg, " +
                "DATE_FORMAT(l.expiry_time, '%Y-%m-%dT%H:%i:%sZ') AS expiryTime, l.status, " +
                "p.id AS pickupId, p.status AS pickupStatus, n.name AS ngo, v.name AS volunteer " +
                "FROM food_listings l JOIN donors d ON d.id = l.donor_id JOIN food_types ft ON ft.id = l.food_type_id " +
                "LEFT JOIN pickups p ON p.listing_id = l.id LEFT JOIN ngos n ON n.id = p.ngo_id " +
                "LEFT JOIN volunteers v ON v.id = p.volunteer_id ORDER BY l.created_at DESC, l.id DESC LIMIT 50");
    }

    /** Insert the listing (DB trigger validates it and notifies eligible NGOs), then rank NGOs for it. */
    public Map<String, Object> create(ListingRequest req) {
        FoodListing l = new FoodListing();
        l.setDonorId(req.getDonorId());
        l.setFoodTypeId(req.getFoodTypeId());
        l.setDescription(req.getDescription());
        l.setQuantityKg(req.getQuantityKg());
        long minutes = req.getHoursUntilExpiry().multiply(BigDecimal.valueOf(60)).longValue();
        l.setExpiryTime(LocalDateTime.now(ZoneOffset.UTC).plusMinutes(minutes));
        FoodListing saved = repo.save(l);
        return Map.of("listingId", saved.getId(), "match", matching.matchListing(saved.getId()));
    }

    public void delete(Long id) {
        FoodListing l = repo.findById(id).orElseThrow(() -> new ApiException(HttpStatus.NOT_FOUND, "Listing not found."));
        if (!"AVAILABLE".equals(l.getStatus())) {
            throw new ApiException(HttpStatus.CONFLICT, "Only AVAILABLE listings can be removed.");
        }
        repo.delete(l);
    }
}
