package com.fooddonation.service;

import com.fooddonation.dto.PickupRequest;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

@Service
public class PickupService {

    private final JdbcTemplate jdbc;

    public PickupService(JdbcTemplate jdbc) {
        this.jdbc = jdbc;
    }

    /** sp_assign_pickup picks the nearest free volunteer; triggers mark the listing MATCHED. */
    public Map<String, Object> confirm(PickupRequest req) {
        jdbc.update("CALL sp_assign_pickup(?,?)", req.getListingId(), req.getNgoId());
        return jdbc.queryForMap(
                "SELECT p.id, p.status, n.name AS ngo, v.name AS volunteer FROM pickups p " +
                "JOIN ngos n ON n.id = p.ngo_id LEFT JOIN volunteers v ON v.id = p.volunteer_id WHERE p.listing_id = ?",
                req.getListingId());
    }

    public void updateStatus(Long pickupId, String status) {
        jdbc.update("CALL sp_update_pickup_status(?,?)", pickupId, status);
    }

    public List<Map<String, Object>> history(Long pickupId) {
        return jdbc.queryForList(
                "SELECT old_status AS oldStatus, new_status AS newStatus, " +
                "DATE_FORMAT(changed_at, '%Y-%m-%dT%H:%i:%sZ') AS changedAt " +
                "FROM pickup_history WHERE pickup_id = ? ORDER BY id", pickupId);
    }
}
