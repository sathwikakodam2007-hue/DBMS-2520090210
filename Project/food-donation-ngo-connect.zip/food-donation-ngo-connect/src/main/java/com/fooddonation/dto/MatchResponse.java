package com.fooddonation.dto;

import java.util.List;
import java.util.Map;

public class MatchResponse {
    private String runId;
    private String verdict;   // MATCH | REVIEW | WEAK | NO_MATCH (verdict of the best candidate)
    private String headline;
    private String body;
    private List<Map<String, Object>> candidates;

    public String getRunId() { return runId; }
    public void setRunId(String runId) { this.runId = runId; }
    public String getVerdict() { return verdict; }
    public void setVerdict(String verdict) { this.verdict = verdict; }
    public String getHeadline() { return headline; }
    public void setHeadline(String headline) { this.headline = headline; }
    public String getBody() { return body; }
    public void setBody(String body) { this.body = body; }
    public List<Map<String, Object>> getCandidates() { return candidates; }
    public void setCandidates(List<Map<String, Object>> candidates) { this.candidates = candidates; }
}
