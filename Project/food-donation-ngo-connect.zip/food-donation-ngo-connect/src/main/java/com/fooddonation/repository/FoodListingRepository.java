package com.fooddonation.repository;

import com.fooddonation.entity.FoodListing;
import org.springframework.data.jpa.repository.JpaRepository;

public interface FoodListingRepository extends JpaRepository<FoodListing, Long> {
}
