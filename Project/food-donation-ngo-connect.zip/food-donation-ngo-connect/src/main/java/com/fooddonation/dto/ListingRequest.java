package com.fooddonation.dto;

import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.NotNull;
import java.math.BigDecimal;

public class ListingRequest {
    @NotNull(message = "Pick a donor.")
    private Long donorId;
    @NotNull(message = "Pick a food type.")
    private Integer foodTypeId;
    private String description;
    @NotNull @DecimalMin(value = "0.1", message = "Quantity must be at least 0.1 kg.")
    private BigDecimal quantityKg;
    @NotNull @DecimalMin(value = "0.5", message = "Hours until expiry must be at least 0.5.")
    private BigDecimal hoursUntilExpiry;

    public Long getDonorId() { return donorId; }
    public void setDonorId(Long donorId) { this.donorId = donorId; }
    public Integer getFoodTypeId() { return foodTypeId; }
    public void setFoodTypeId(Integer foodTypeId) { this.foodTypeId = foodTypeId; }
    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }
    public BigDecimal getQuantityKg() { return quantityKg; }
    public void setQuantityKg(BigDecimal quantityKg) { this.quantityKg = quantityKg; }
    public BigDecimal getHoursUntilExpiry() { return hoursUntilExpiry; }
    public void setHoursUntilExpiry(BigDecimal hoursUntilExpiry) { this.hoursUntilExpiry = hoursUntilExpiry; }
}
