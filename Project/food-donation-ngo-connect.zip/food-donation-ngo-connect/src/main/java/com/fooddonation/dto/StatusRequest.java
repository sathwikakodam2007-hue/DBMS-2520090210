package com.fooddonation.dto;

import jakarta.validation.constraints.NotBlank;

public class StatusRequest {
    @NotBlank private String status; // PICKED_UP | DELIVERED

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
}
