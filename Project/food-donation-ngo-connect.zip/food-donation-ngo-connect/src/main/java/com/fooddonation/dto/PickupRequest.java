package com.fooddonation.dto;

import jakarta.validation.constraints.NotNull;

public class PickupRequest {
    @NotNull private Long listingId;
    @NotNull private Long ngoId;

    public Long getListingId() { return listingId; }
    public void setListingId(Long listingId) { this.listingId = listingId; }
    public Long getNgoId() { return ngoId; }
    public void setNgoId(Long ngoId) { this.ngoId = ngoId; }
}
