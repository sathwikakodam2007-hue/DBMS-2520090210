package com.fooddonation.entity;

import jakarta.persistence.*;
import java.math.BigDecimal;
import java.time.LocalDateTime;

@Entity
@Table(name = "food_listings")
public class FoodListing {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "donor_id", nullable = false)
    private Long donorId;

    @Column(name = "food_type_id", nullable = false)
    private Integer foodTypeId;

    private String description;

    @Column(name = "quantity_kg", nullable = false, precision = 8, scale = 2)
    private BigDecimal quantityKg;

    @Column(name = "expiry_time", nullable = false)
    private LocalDateTime expiryTime; // UTC

    @Column(nullable = false, length = 20)
    private String status = "AVAILABLE"; // AVAILABLE | MATCHED | PICKED_UP | DELIVERED

    @Column(name = "created_at", updatable = false)
    private LocalDateTime createdAt = LocalDateTime.now(java.time.ZoneOffset.UTC);

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public Long getDonorId() { return donorId; }
    public void setDonorId(Long donorId) { this.donorId = donorId; }
    public Integer getFoodTypeId() { return foodTypeId; }
    public void setFoodTypeId(Integer foodTypeId) { this.foodTypeId = foodTypeId; }
    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }
    public BigDecimal getQuantityKg() { return quantityKg; }
    public void setQuantityKg(BigDecimal quantityKg) { this.quantityKg = quantityKg; }
    public LocalDateTime getExpiryTime() { return expiryTime; }
    public void setExpiryTime(LocalDateTime expiryTime) { this.expiryTime = expiryTime; }
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
    public LocalDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(LocalDateTime createdAt) { this.createdAt = createdAt; }
}
