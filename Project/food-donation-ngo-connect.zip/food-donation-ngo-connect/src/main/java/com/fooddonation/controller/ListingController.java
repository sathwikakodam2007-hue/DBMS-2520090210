package com.fooddonation.controller;

import com.fooddonation.dto.ListingRequest;
import com.fooddonation.dto.MatchResponse;
import com.fooddonation.service.ListingService;
import com.fooddonation.service.MatchingService;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/listings")
public class ListingController {

    private final ListingService listingService;
    private final MatchingService matchingService;

    public ListingController(ListingService listingService, MatchingService matchingService) {
        this.listingService = listingService;
        this.matchingService = matchingService;
    }

    @GetMapping
    public List<Map<String, Object>> all() {
        return listingService.findAll();
    }

    @PostMapping
    public ResponseEntity<Map<String, Object>> create(@Valid @RequestBody ListingRequest request) {
        return ResponseEntity.ok(listingService.create(request));
    }

    @GetMapping("/{id}/matches")
    public MatchResponse matches(@PathVariable Long id) {
        return matchingService.matchListing(id);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        listingService.delete(id);
        return ResponseEntity.noContent().build();
    }
}
