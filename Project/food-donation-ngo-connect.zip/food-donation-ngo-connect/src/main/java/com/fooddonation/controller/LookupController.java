package com.fooddonation.controller;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

/** Public reference data for the dropdowns (localities, food types, donors, NGOs). */
@RestController
@RequestMapping("/api/lookups")
public class LookupController {

    private final JdbcTemplate jdbc;

    public LookupController(JdbcTemplate jdbc) {
        this.jdbc = jdbc;
    }

    @GetMapping
    public Map<String, Object> all() {
        return Map.of(
                "localities", jdbc.queryForList("SELECT id, name FROM localities ORDER BY name"),
                "foodTypes", jdbc.queryForList("SELECT id, name FROM food_types ORDER BY id"),
                "donors", jdbc.queryForList("SELECT id, name FROM donors ORDER BY name"),
                "ngos", jdbc.queryForList("SELECT id, name FROM ngos ORDER BY name"));
    }
}
