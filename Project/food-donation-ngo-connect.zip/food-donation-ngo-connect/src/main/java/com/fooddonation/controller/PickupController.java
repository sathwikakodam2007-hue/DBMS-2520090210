package com.fooddonation.controller;

import com.fooddonation.dto.PickupRequest;
import com.fooddonation.dto.StatusRequest;
import com.fooddonation.service.PickupService;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/pickups")
public class PickupController {

    private final PickupService pickupService;

    public PickupController(PickupService pickupService) {
        this.pickupService = pickupService;
    }

    @PostMapping
    public Map<String, Object> confirm(@Valid @RequestBody PickupRequest request) {
        return pickupService.confirm(request);
    }

    @PutMapping("/{id}/status")
    public ResponseEntity<Void> status(@PathVariable Long id, @Valid @RequestBody StatusRequest request) {
        pickupService.updateStatus(id, request.getStatus());
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/{id}/history")
    public List<Map<String, Object>> history(@PathVariable Long id) {
        return pickupService.history(id);
    }
}
