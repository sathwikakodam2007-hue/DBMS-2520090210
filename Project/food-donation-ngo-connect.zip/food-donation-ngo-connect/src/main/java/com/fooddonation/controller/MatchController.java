package com.fooddonation.controller;

import com.fooddonation.dto.MatchRequest;
import com.fooddonation.dto.MatchResponse;
import com.fooddonation.service.MatchingService;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/match")
public class MatchController {

    private final MatchingService matchingService;

    public MatchController(MatchingService matchingService) {
        this.matchingService = matchingService;
    }

    @PostMapping
    public ResponseEntity<MatchResponse> match(@Valid @RequestBody MatchRequest request) {
        return ResponseEntity.ok(matchingService.match(request));
    }
}
