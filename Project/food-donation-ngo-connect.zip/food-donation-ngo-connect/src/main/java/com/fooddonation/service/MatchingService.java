package com.fooddonation.service;

import com.fooddonation.dto.MatchRequest;
import com.fooddonation.dto.MatchResponse;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import java.sql.Types;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * The scoring itself lives in MySQL (sp_match_candidates + fn_distance_km), so the rules are
 * enforced next to the data. This service calls the procedure and reads back the audit rows.
 */
@Service
public class MatchingService {

    private final JdbcTemplate jdbc;

    public MatchingService(JdbcTemplate jdbc) {
        this.jdbc = jdbc;
    }

    /** Public demo: score an ad-hoc donation; every candidate is persisted to match_log. */
    public MatchResponse match(MatchRequest req) {
        String run = UUID.randomUUID().toString();
        jdbc.update("CALL sp_match_candidates(?,?,?,?,?,?,?)",
                new Object[]{run, null, null, req.getLocalityId(), req.getFoodTypeId(),
                        req.getQuantityKg(), req.getHoursUntilExpiry()},
                new int[]{Types.CHAR, Types.BIGINT, Types.BIGINT, Types.INTEGER, Types.INTEGER,
                        Types.DECIMAL, Types.DECIMAL});
        return describe(run);
    }

    /** Re-run matching for a stored listing (only while it is still AVAILABLE). */
    public MatchResponse matchListing(Long listingId) {
        String run = UUID.randomUUID().toString();
        jdbc.update("CALL sp_match_listing(?,?)", run, listingId);
        return describe(run);
    }

    public List<Map<String, Object>> ranked(String runId) {
        return jdbc.queryForList(
                "SELECT m.ngo_id AS ngoId, n.name AS ngo, loc.name AS locality, m.distance_km AS distanceKm, " +
                "m.proximity_score AS proximityScore, m.quantity_score AS quantityScore, " +
                "m.urgency_score AS urgencyScore, m.priority_score AS priorityScore, " +
                "m.verdict AS verdict, m.criteria AS criteria " +
                "FROM match_log m JOIN ngos n ON n.id = m.ngo_id JOIN localities loc ON loc.id = n.locality_id " +
                "WHERE m.run_id = ? ORDER BY m.priority_score DESC, m.distance_km ASC", runId);
    }

    private MatchResponse describe(String run) {
        List<Map<String, Object>> candidates = ranked(run);
        MatchResponse r = new MatchResponse();
        r.setRunId(run);
        r.setCandidates(candidates);
        if (candidates.isEmpty()) {
            r.setVerdict("NO_MATCH");
            r.setHeadline("No eligible NGO right now");
            r.setBody("No NGO accepts this food type within its service radius and batch range while the food is still "
                    + "fresh enough to reach it. The listing stays AVAILABLE and can be re-matched.");
            return r;
        }
        Map<String, Object> best = candidates.get(0);
        String v = String.valueOf(best.get("verdict"));
        r.setVerdict(v);
        switch (v) {
            case "MATCH" -> r.setHeadline("Verified match found");
            case "REVIEW" -> r.setHeadline("Candidates need a quick review");
            default -> r.setHeadline("Only weak candidates available");
        }
        r.setBody(candidates.size() + " eligible NGO(s). Best: " + best.get("ngo") + " ("
                + best.get("distanceKm") + " km, priority " + best.get("priorityScore") + ").");
        return r;
    }
}
