-- Food Donation & NGO Connect Platform: 3NF schema (all timestamps are UTC)

CREATE TABLE users (
    id            BIGINT AUTO_INCREMENT PRIMARY KEY,
    name          VARCHAR(255) NOT NULL,
    email         VARCHAR(255) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    created_at    TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE localities (
    id        INT AUTO_INCREMENT PRIMARY KEY,
    name      VARCHAR(100) NOT NULL UNIQUE,
    latitude  DECIMAL(9,6) NOT NULL,
    longitude DECIMAL(9,6) NOT NULL
);

CREATE TABLE food_types (
    id   INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(60) NOT NULL UNIQUE
);

CREATE TABLE donors (
    id          BIGINT AUTO_INCREMENT PRIMARY KEY,
    name        VARCHAR(255) NOT NULL,
    donor_type  VARCHAR(20) NOT NULL,            -- RESTAURANT | HOUSEHOLD | EVENT
    phone       VARCHAR(20),
    locality_id INT NOT NULL,
    CONSTRAINT fk_donor_locality FOREIGN KEY (locality_id) REFERENCES localities(id)
);

CREATE TABLE ngos (
    id                BIGINT AUTO_INCREMENT PRIMARY KEY,
    name              VARCHAR(255) NOT NULL,
    phone             VARCHAR(20),
    locality_id       INT NOT NULL,
    service_radius_km DECIMAL(5,2) NOT NULL DEFAULT 10,
    min_batch_kg      DECIMAL(8,2) NOT NULL DEFAULT 1,     -- quantity range filter
    max_batch_kg      DECIMAL(8,2) NOT NULL DEFAULT 100,
    CONSTRAINT fk_ngo_locality FOREIGN KEY (locality_id) REFERENCES localities(id)
);

-- M:N: which food types an NGO accepts
CREATE TABLE ngo_food_types (
    ngo_id       BIGINT NOT NULL,
    food_type_id INT NOT NULL,
    PRIMARY KEY (ngo_id, food_type_id),
    CONSTRAINT fk_nft_ngo  FOREIGN KEY (ngo_id) REFERENCES ngos(id) ON DELETE CASCADE,
    CONSTRAINT fk_nft_type FOREIGN KEY (food_type_id) REFERENCES food_types(id)
);

CREATE TABLE volunteers (
    id          BIGINT AUTO_INCREMENT PRIMARY KEY,
    name        VARCHAR(255) NOT NULL,
    phone       VARCHAR(20),
    locality_id INT NOT NULL,
    available   BOOLEAN NOT NULL DEFAULT TRUE,
    CONSTRAINT fk_vol_locality FOREIGN KEY (locality_id) REFERENCES localities(id)
);

CREATE TABLE food_listings (
    id           BIGINT AUTO_INCREMENT PRIMARY KEY,
    donor_id     BIGINT NOT NULL,
    food_type_id INT NOT NULL,
    description  VARCHAR(255),
    quantity_kg  DECIMAL(8,2) NOT NULL,
    expiry_time  DATETIME NOT NULL,
    status       VARCHAR(20) NOT NULL DEFAULT 'AVAILABLE',  -- AVAILABLE | MATCHED | PICKED_UP | DELIVERED
    created_at   DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_listing_donor FOREIGN KEY (donor_id) REFERENCES donors(id),
    CONSTRAINT fk_listing_type  FOREIGN KEY (food_type_id) REFERENCES food_types(id),
    INDEX idx_listing_status_expiry (status, expiry_time)   -- B-tree: nearby/expiring listings
);

CREATE TABLE pickups (
    id           BIGINT AUTO_INCREMENT PRIMARY KEY,
    listing_id   BIGINT NOT NULL UNIQUE,
    ngo_id       BIGINT NOT NULL,
    volunteer_id BIGINT,
    status       VARCHAR(20) NOT NULL DEFAULT 'ASSIGNED',   -- ASSIGNED -> PICKED_UP -> DELIVERED
    created_at   DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_pickup_listing   FOREIGN KEY (listing_id) REFERENCES food_listings(id),
    CONSTRAINT fk_pickup_ngo       FOREIGN KEY (ngo_id) REFERENCES ngos(id),
    CONSTRAINT fk_pickup_volunteer FOREIGN KEY (volunteer_id) REFERENCES volunteers(id)
);

-- Audit: every status change of a pickup (written by trigger)
CREATE TABLE pickup_history (
    id         BIGINT AUTO_INCREMENT PRIMARY KEY,
    pickup_id  BIGINT NOT NULL,
    old_status VARCHAR(20),
    new_status VARCHAR(20) NOT NULL,
    changed_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_hist_pickup FOREIGN KEY (pickup_id) REFERENCES pickups(id)
);

-- NGO notifications (written by trigger on new listings)
CREATE TABLE notifications (
    id         BIGINT AUTO_INCREMENT PRIMARY KEY,
    ngo_id     BIGINT NOT NULL,
    listing_id BIGINT NOT NULL,
    message    VARCHAR(255) NOT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_notif_ngo     FOREIGN KEY (ngo_id) REFERENCES ngos(id),
    CONSTRAINT fk_notif_listing FOREIGN KEY (listing_id) REFERENCES food_listings(id) ON DELETE CASCADE
);

-- Audit: which donor, NGO and criteria produced each candidate match.
-- listing_id / donor_id are NULL for ad-hoc demo runs. No FK on listing_id so the audit survives deletes.
CREATE TABLE match_log (
    id              BIGINT AUTO_INCREMENT PRIMARY KEY,
    run_id          CHAR(36) NOT NULL,
    listing_id      BIGINT,
    donor_id        BIGINT,
    ngo_id          BIGINT NOT NULL,
    distance_km     DECIMAL(8,3) NOT NULL,
    proximity_score DECIMAL(4,3) NOT NULL,
    quantity_score  DECIMAL(4,3) NOT NULL,
    urgency_score   DECIMAL(4,3) NOT NULL,
    priority_score  DECIMAL(4,3) NOT NULL,
    verdict         VARCHAR(20) NOT NULL,                   -- MATCH | REVIEW | WEAK
    criteria        VARCHAR(255) NOT NULL,
    created_at      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_log_ngo FOREIGN KEY (ngo_id) REFERENCES ngos(id),
    INDEX idx_log_run (run_id)
);
