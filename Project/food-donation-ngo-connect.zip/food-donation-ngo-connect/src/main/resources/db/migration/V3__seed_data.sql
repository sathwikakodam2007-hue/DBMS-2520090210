-- Sample data (fictional organisations) so the matching demo works on first run.
INSERT INTO localities (name, latitude, longitude) VALUES
 ('Quthbullapur',   17.5100, 78.4600), ('Bachupally',    17.5440, 78.3860),
 ('Kukatpally',     17.4948, 78.3996), ('Miyapur',       17.4969, 78.3548),
 ('Kondapur',       17.4700, 78.3570), ('Madhapur',      17.4486, 78.3908),
 ('Gachibowli',     17.4401, 78.3489), ('Jubilee Hills', 17.4326, 78.4071),
 ('Ameerpet',       17.4375, 78.4483), ('Secunderabad',  17.4399, 78.4983);

INSERT INTO food_types (name) VALUES
 ('Cooked meals'), ('Bakery'), ('Fresh produce'), ('Packaged food'), ('Dairy');

INSERT INTO donors (name, donor_type, phone, locality_id) VALUES
 ('Spice Route Restaurant (sample)', 'RESTAURANT', '9000000001', (SELECT id FROM localities WHERE name='Kukatpally')),
 ('Green Leaf Caterers (sample)',    'EVENT',      '9000000002', (SELECT id FROM localities WHERE name='Bachupally')),
 ('Sharma Household (sample)',       'HOUSEHOLD',  '9000000003', (SELECT id FROM localities WHERE name='Quthbullapur')),
 ('Crust & Crumb Bakery (sample)',   'RESTAURANT', '9000000004', (SELECT id FROM localities WHERE name='Madhapur')),
 ('Grand Hall Events (sample)',      'EVENT',      '9000000005', (SELECT id FROM localities WHERE name='Secunderabad'));

INSERT INTO ngos (name, phone, locality_id, service_radius_km, min_batch_kg, max_batch_kg) VALUES
 ('Hope Meals Trust (sample)',      '9100000001', (SELECT id FROM localities WHERE name='Kukatpally'),   12, 2, 150),
 ('Sunrise Shelter (sample)',       '9100000002', (SELECT id FROM localities WHERE name='Miyapur'),      10, 1, 60),
 ('Little Hands Foundation (sample)','9100000003',(SELECT id FROM localities WHERE name='Quthbullapur'),  8, 1, 40),
 ('City Care Kitchen (sample)',     '9100000004', (SELECT id FROM localities WHERE name='Ameerpet'),     15, 5, 200),
 ('Anna Seva Society (sample)',     '9100000005', (SELECT id FROM localities WHERE name='Gachibowli'),   10, 2, 80);

-- every NGO takes cooked meals; the rest vary
INSERT INTO ngo_food_types (ngo_id, food_type_id)
SELECT n.id, ft.id FROM ngos n JOIN food_types ft ON ft.name='Cooked meals';
INSERT INTO ngo_food_types (ngo_id, food_type_id)
SELECT n.id, ft.id FROM ngos n JOIN food_types ft ON ft.name IN ('Bakery','Packaged food')
 WHERE n.name LIKE 'Hope%' OR n.name LIKE 'Sunrise%' OR n.name LIKE 'Little%';
INSERT INTO ngo_food_types (ngo_id, food_type_id)
SELECT n.id, ft.id FROM ngos n JOIN food_types ft ON ft.name IN ('Fresh produce','Dairy')
 WHERE n.name LIKE 'City%' OR n.name LIKE 'Anna%' OR n.name LIKE 'Hope%';

INSERT INTO volunteers (name, phone, locality_id) VALUES
 ('Ravi (sample)',  '9200000001', (SELECT id FROM localities WHERE name='Kukatpally')),
 ('Meera (sample)', '9200000002', (SELECT id FROM localities WHERE name='Bachupally')),
 ('Imran (sample)', '9200000003', (SELECT id FROM localities WHERE name='Madhapur')),
 ('Latha (sample)', '9200000004', (SELECT id FROM localities WHERE name='Secunderabad'));
