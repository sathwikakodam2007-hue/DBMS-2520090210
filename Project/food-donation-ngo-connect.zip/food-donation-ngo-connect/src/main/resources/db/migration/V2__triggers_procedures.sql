-- Haversine distance in km (stored function used by every matching query)
DELIMITER $$
CREATE FUNCTION fn_distance_km(lat1 DECIMAL(9,6), lon1 DECIMAL(9,6), lat2 DECIMAL(9,6), lon2 DECIMAL(9,6))
RETURNS DECIMAL(8,3) DETERMINISTIC
BEGIN
    RETURN 6371 * 2 * ASIN(SQRT(
        POWER(SIN(RADIANS(lat2 - lat1) / 2), 2) +
        COS(RADIANS(lat1)) * COS(RADIANS(lat2)) * POWER(SIN(RADIANS(lon2 - lon1) / 2), 2)));
END$$

-- Core matching: hard filters (food type, radius, quantity range, reachable before expiry),
-- then weighted priority = 0.5*proximity + 0.3*quantity + 0.2*urgency. Every candidate is logged.
CREATE PROCEDURE sp_match_candidates(
    IN p_run CHAR(36), IN p_listing BIGINT, IN p_donor BIGINT, IN p_locality INT,
    IN p_food_type INT, IN p_qty DECIMAL(8,2), IN p_hours DECIMAL(6,2))
BEGIN
    INSERT INTO match_log (run_id, listing_id, donor_id, ngo_id, distance_km,
                           proximity_score, quantity_score, urgency_score, priority_score, verdict, criteria)
    SELECT p_run, p_listing, p_donor, s.ngo_id, s.d, s.ps, s.qs, s.us, s.pr,
           CASE WHEN s.pr >= 0.60 THEN 'MATCH' WHEN s.pr >= 0.35 THEN 'REVIEW' ELSE 'WEAK' END,
           CONCAT('food type accepted; ', s.d, ' km within ', s.radius, ' km radius; ',
                  p_qty, ' kg within ', s.minb, '-', s.maxb, ' kg; reachable before expiry')
    FROM (
        SELECT q.*, ROUND(0.5 * q.ps + 0.3 * q.qs + 0.2 * q.us, 3) AS pr
        FROM (
            SELECT b.*,
                   ROUND(GREATEST(0, 1 - b.d / b.radius), 3)    AS ps,
                   ROUND(LEAST(1, p_qty / b.maxb), 3)           AS qs,
                   ROUND(GREATEST(0, LEAST(1, 1 - p_hours / 24)), 3) AS us
            FROM (
                SELECT n.id AS ngo_id, n.service_radius_km AS radius,
                       n.min_batch_kg AS minb, n.max_batch_kg AS maxb,
                       fn_distance_km(src.latitude, src.longitude, nl.latitude, nl.longitude) AS d
                FROM ngos n
                JOIN ngo_food_types nft ON nft.ngo_id = n.id AND nft.food_type_id = p_food_type
                JOIN localities nl  ON nl.id  = n.locality_id
                JOIN localities src ON src.id = p_locality
                WHERE p_qty BETWEEN n.min_batch_kg AND n.max_batch_kg
            ) b
            WHERE b.d <= b.radius
              AND p_hours * 60 >= b.d * 2.4 + 30      -- ~25 km/h travel + 30 min handling
        ) q
    ) s;
END$$

-- Match a stored listing (reads its donor location, type, quantity and remaining shelf life)
CREATE PROCEDURE sp_match_listing(IN p_run CHAR(36), IN p_listing BIGINT)
BEGIN
    DECLARE v_donor BIGINT;
    DECLARE v_loc INT;
    DECLARE v_type INT;
    DECLARE v_qty DECIMAL(8,2);
    DECLARE v_hours DECIMAL(6,2);

    SELECT l.donor_id, d.locality_id, l.food_type_id, l.quantity_kg,
           TIMESTAMPDIFF(MINUTE, UTC_TIMESTAMP(), l.expiry_time) / 60
      INTO v_donor, v_loc, v_type, v_qty, v_hours
      FROM food_listings l JOIN donors d ON d.id = l.donor_id
     WHERE l.id = p_listing AND l.status = 'AVAILABLE';

    IF v_donor IS NOT NULL THEN
        CALL sp_match_candidates(p_run, p_listing, v_donor, v_loc, v_type, v_qty, v_hours);
    END IF;
END$$

-- Confirm a match: create the pickup with the nearest available volunteer
CREATE PROCEDURE sp_assign_pickup(IN p_listing BIGINT, IN p_ngo BIGINT)
BEGIN
    DECLARE v_status VARCHAR(20) DEFAULT NULL;
    DECLARE v_vol BIGINT DEFAULT NULL;

    SELECT status INTO v_status FROM food_listings WHERE id = p_listing FOR UPDATE;
    IF v_status IS NULL THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Listing not found.';
    END IF;
    IF v_status <> 'AVAILABLE' THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Listing is no longer available.';
    END IF;

    SELECT v.id INTO v_vol
      FROM volunteers v
      JOIN localities vl ON vl.id = v.locality_id
      JOIN food_listings l ON l.id = p_listing
      JOIN donors d ON d.id = l.donor_id
      JOIN localities dl ON dl.id = d.locality_id
     WHERE v.available = TRUE
     ORDER BY fn_distance_km(vl.latitude, vl.longitude, dl.latitude, dl.longitude)
     LIMIT 1;

    INSERT INTO pickups (listing_id, ngo_id, volunteer_id, status)
    VALUES (p_listing, p_ngo, v_vol, 'ASSIGNED');
END$$

-- Status-update procedure: ASSIGNED -> PICKED_UP -> DELIVERED only
CREATE PROCEDURE sp_update_pickup_status(IN p_pickup BIGINT, IN p_new VARCHAR(20))
BEGIN
    DECLARE v_old VARCHAR(20) DEFAULT NULL;

    SELECT status INTO v_old FROM pickups WHERE id = p_pickup FOR UPDATE;
    IF v_old IS NULL THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Pickup not found.';
    END IF;
    IF NOT ((v_old = 'ASSIGNED' AND p_new = 'PICKED_UP') OR (v_old = 'PICKED_UP' AND p_new = 'DELIVERED')) THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Invalid status transition.';
    END IF;
    UPDATE pickups SET status = p_new WHERE id = p_pickup;
END$$

-- Validate new listings
CREATE TRIGGER trg_listing_before_insert BEFORE INSERT ON food_listings FOR EACH ROW
BEGIN
    IF NEW.quantity_kg <= 0 THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Quantity must be greater than zero.';
    END IF;
    IF NEW.expiry_time <= UTC_TIMESTAMP() THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Expiry time must be in the future.';
    END IF;
END$$

-- Notify every eligible NGO automatically when a matching donation is inserted
CREATE TRIGGER trg_listing_after_insert AFTER INSERT ON food_listings FOR EACH ROW
BEGIN
    INSERT INTO notifications (ngo_id, listing_id, message)
    SELECT n.id, NEW.id,
           CONCAT('New ', ft.name, ' donation: ', NEW.quantity_kg, ' kg, ',
                  ROUND(fn_distance_km(dl.latitude, dl.longitude, nl.latitude, nl.longitude), 1), ' km away')
      FROM ngos n
      JOIN ngo_food_types nft ON nft.ngo_id = n.id AND nft.food_type_id = NEW.food_type_id
      JOIN food_types ft ON ft.id = NEW.food_type_id
      JOIN localities nl ON nl.id = n.locality_id
      JOIN donors d ON d.id = NEW.donor_id
      JOIN localities dl ON dl.id = d.locality_id
     WHERE NEW.quantity_kg BETWEEN n.min_batch_kg AND n.max_batch_kg
       AND fn_distance_km(dl.latitude, dl.longitude, nl.latitude, nl.longitude) <= n.service_radius_km;
END$$

-- New pickup: mark listing MATCHED, lock the volunteer, start the audit trail
CREATE TRIGGER trg_pickup_after_insert AFTER INSERT ON pickups FOR EACH ROW
BEGIN
    UPDATE food_listings SET status = 'MATCHED' WHERE id = NEW.listing_id;
    IF NEW.volunteer_id IS NOT NULL THEN
        UPDATE volunteers SET available = FALSE WHERE id = NEW.volunteer_id;
    END IF;
    INSERT INTO pickup_history (pickup_id, old_status, new_status) VALUES (NEW.id, NULL, NEW.status);
END$$

-- Status change: sync listing status, free the volunteer on delivery, log history
CREATE TRIGGER trg_pickup_after_update AFTER UPDATE ON pickups FOR EACH ROW
BEGIN
    IF NEW.status <> OLD.status THEN
        INSERT INTO pickup_history (pickup_id, old_status, new_status) VALUES (NEW.id, OLD.status, NEW.status);
        UPDATE food_listings SET status = NEW.status WHERE id = NEW.listing_id;
        IF NEW.status = 'DELIVERED' AND NEW.volunteer_id IS NOT NULL THEN
            UPDATE volunteers SET available = TRUE WHERE id = NEW.volunteer_id;
        END IF;
    END IF;
END$$
DELIMITER ;
